
import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.API_KEY;
if (!API_KEY) {
  throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const PROMPT = `
أنت خبير في استخراج النصوص من صور المانهوا والويب تون والكوميكس. مهمتك هي تحليل الصورة المرفقة واستخراج كل النصوص الموجودة فيها بدقة.
يجب عليك تصنيف كل نص حسب نوعه ووضع علامة مميزة قبله في سطر منفصل.

استخدم العلامات التالية للتصنيف:
# : للنص داخل فقاعة كلام عادية.
$ : للنص داخل فقاعة تفكير أو همس.
& : للنص داخل مربع السرد (النص الخارجي الذي يشرح الأحداث).
( : للنص الذي يمثل مؤثرات صوتية (SFX) مثل "بووم"، "كراك".
) : للنص داخل فقاعة صراخ أو كلام بصوت عالٍ جدًا.
/ : للنص داخل فقاعة نظام أو شاشة معلومات (مثل شاشات الألعاب أو الرسائل الرسمية).
_ : لأي نص آخر لا يندرج تحت التصنيفات السابقة (مثل نص على لافتة أو كتاب).

قواعد هامة:
1.  رتب النصوص المستخرجة حسب ترتيب ظهورها في الصورة من الأعلى إلى الأسفل.
2.  لا تضف أي تعليقات أو مقدمات أو خواتيم. النتيجة يجب أن تكون فقط قائمة بالنصوص المصنفة.
3.  إذا كانت الفقاعة تحتوي على عدة أسطر، ادمجها في سطر واحد بعد العلامة.
4.  حافظ على النص الأصلي كما هو، بما في ذلك علامات الترقيم.
`;


export async function extractTextFromImage(base64Image: string, mimeType: string): Promise<string> {
  try {
    const imagePart = {
      inlineData: {
        data: base64Image,
        mimeType: mimeType,
      },
    };

    const textPart = {
      text: PROMPT,
    };
    
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts: [textPart, imagePart] },
        config: {
            temperature: 0.1,
        }
    });

    return response.text.trim();
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to extract text from image via Gemini API.");
  }
}
